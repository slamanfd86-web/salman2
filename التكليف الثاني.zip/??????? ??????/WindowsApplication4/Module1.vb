﻿Module Module1
    Public x, y As Integer

End Module
